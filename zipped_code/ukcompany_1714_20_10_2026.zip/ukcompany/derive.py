"""Derive layer: cached raw JSON -> flat attribute records. Pure functions.

Rules for this module:
  * .get() everything - older records have missing/inconsistent fields, and a
    KeyError on company 340 of 500 is not acceptable.
  * No network access. Input is the cache, full stop.
  * Ages/elapsed times are computed against the response's fetched_at, not
    "now", so a re-derive months later reproduces the original values.
  * Attributes carry everything useful (Tier 2/3 included: SIC, accounts
    category, ...). The flag registry in rules.py restricts itself to Tier 1;
    this table does not.
"""

from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any

from .cache import CachedResponse
from .psc_natures import classify_kind, is_uk_company_number_format, summarise_natures

log = logging.getLogger(__name__)

# CH company_status values that mean "no longer a live entity" - these gate
# screenability (exclusions table) rather than acting as risk flags.
EXCLUDED_STATUSES = {"dissolved", "converted-closed", "closed", "removed"}

# Statuses indicating a live insolvency-type process.
INSOLVENT_STATUSES = {
    "liquidation",
    "administration",
    "receivership",
    "voluntary-arrangement",
    "insolvency-proceedings",
}


def _parse_date(s: str | None) -> date | None:
    if not s:
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _months_between(start: date, end: date) -> int:
    return (end.year - start.year) * 12 + (end.month - start.month)


def _id_verification_counts(items: list[dict[str, Any]]) -> tuple[int, int, int]:
    """(n_id_verified, n_id_verification_due, n_id_statement_filed) over officer /
    PSC list items.

    ECCTA identity verification is live in responses under the item's
    `identity_verification_details` block (key names observed live 2026-08; see
    docs/AUDIT.md). We read, defensively:
      * verified        = the block is present (the appointment is inside the
        identity-verification regime);
      * due             = a verification statement is due
        (`appointment_verification_statement_due_on`) with no completed identity
        verification (`identity_verified_on` absent);
      * statement_filed = an appointment verification statement has been filed
        (`appointment_verification_statement_date` present) - a SEPARATE signal
        from identity verification: a filed statement does not by itself set
        `identity_verified_on`, so it does not clear the `due` count.
    Absence of the block means unverified-or-not-yet-due, NOT non-compliance.
    """
    n_verified = n_due = n_statement_filed = 0
    for it in items:
        ivd = it.get("identity_verification_details")
        if not isinstance(ivd, dict):
            continue
        n_verified += 1
        if ivd.get("appointment_verification_statement_due_on") and not ivd.get(
            "identity_verified_on"
        ):
            n_due += 1
        if ivd.get("appointment_verification_statement_date"):
            n_statement_filed += 1
    return n_verified, n_due, n_statement_filed


def _psc_item_ceased(r: dict[str, Any]) -> bool:
    """A PSC list item is ceased when the live `ceased` boolean says so; fall
    back to `ceased_on` presence for older records that predate the boolean."""
    c = r.get("ceased")
    if c is not None:
        return bool(c)
    return r.get("ceased_on") is not None


def _psc_active_ceased(
    data: dict[str, Any], records: list[dict[str, Any]], company_number: str
) -> tuple[int, int]:
    """(n_active, n_ceased) with the precedence the live API demands:

      (a) authoritative top-level `active_count` / `ceased_count`;
      (b) the per-item `ceased` boolean;
      (c) `ceased_on` presence (last resort).

    The list resource can omit ceased items entirely, so per-item counting alone
    undercounts. When the top-level counts and the per-item tally disagree, the
    top-level counts win and the disagreement is logged (never silently
    reconciled).
    """
    item_ceased = sum(1 for r in records if _psc_item_ceased(r))
    top_ceased = data.get("ceased_count")
    top_active = data.get("active_count")
    if top_ceased is not None:
        if top_ceased != item_ceased:
            log.warning(
                "PSC ceased count mismatch for %s: top-level ceased_count=%s, "
                "per-item ceased=%s; using top-level.",
                company_number,
                top_ceased,
                item_ceased,
            )
        n_ceased = top_ceased
        n_active = top_active if top_active is not None else max(len(records) - n_ceased, 0)
    else:
        n_ceased = item_ceased
        n_active = len(records) - n_ceased
    return n_active, n_ceased


def derive_profile(cached: CachedResponse) -> dict[str, Any]:
    """Flatten one cached profile response into an attribute record."""
    observed_at: datetime = cached.fetched_at
    observed_date = observed_at.date()
    base: dict[str, Any] = {
        "company_number": cached.company_number,
        "observed_at": observed_at.isoformat(),
        "found": not cached.not_found,
    }
    if cached.not_found or cached.data is None:
        return base

    d = cached.data
    accounts = d.get("accounts") or {}
    last_accounts = accounts.get("last_accounts") or {}
    next_accounts = accounts.get("next_accounts") or {}
    conf = d.get("confirmation_statement") or {}
    office = d.get("registered_office_address") or {}
    links = d.get("links") or {}
    previous_names = d.get("previous_company_names") or []

    creation = _parse_date(d.get("date_of_creation"))
    annotations = d.get("corporate_annotation") or []
    ard = accounts.get("accounting_reference_date") or {}

    base.update(
        {
            "company_name": d.get("company_name"),
            "company_status": d.get("company_status"),
            "company_status_detail": d.get("company_status_detail"),
            "company_type": d.get("type"),
            "subtype": d.get("subtype"),
            "jurisdiction": d.get("jurisdiction"),
            "date_of_creation": d.get("date_of_creation"),
            "age_months": _months_between(creation, observed_date) if creation else None,
            "sic_codes": ",".join(d.get("sic_codes") or []),
            "n_previous_names": len(previous_names),
            # accounts / confirmation statement (Tier 1: CH-computed).
            # Spec (checked 2026-08): accounts.overdue and accounts.next_due are
            # deprecated in favour of accounts.next_accounts.* - prefer the new
            # fields, fall back to the deprecated ones for older cached data.
            "accounts_overdue": _first_not_none(
                next_accounts.get("overdue"), accounts.get("overdue")
            ),
            "accounts_next_due": next_accounts.get("due_on") or accounts.get("next_due"),
            "last_accounts_type": last_accounts.get("type"),
            "last_accounts_period_end": last_accounts.get("period_end_on")
            or last_accounts.get("made_up_to"),
            "confirmation_statement_overdue": conf.get("overdue"),
            "confirmation_statement_next_due": conf.get("next_due"),
            # event indicators (Tier 1). The has_* booleans are deprecated per the
            # spec ("Please use links.charges / links.insolvency") - links are
            # primary, booleans retained as corroborating fallback only.
            "has_charges_link": bool(links.get("charges")),
            "has_charges": d.get("has_charges"),
            "has_insolvency_link": bool(links.get("insolvency")),
            "has_insolvency_history": d.get("has_insolvency_history"),
            "has_been_liquidated": d.get("has_been_liquidated"),
            # legally protected PSCs are withheld from the register - absence of a
            # visible PSC record can be explained by this, not by "none reported".
            "has_super_secure_pscs": d.get("has_super_secure_pscs"),
            "registered_office_is_in_dispute": d.get("registered_office_is_in_dispute"),
            "undeliverable_registered_office_address": d.get(
                "undeliverable_registered_office_address"
            ),
            # address context (Tier 2; phase-2 population features join on these)
            "office_postcode": office.get("postal_code"),
            "office_locality": office.get("locality"),
            # screenability gate
            "excluded_status": (d.get("company_status") in EXCLUDED_STATUSES),
            # registrar-published messages about the company (rare; Tier 1)
            "n_corporate_annotations": len(annotations),
            "corporate_annotation_types": ",".join(
                sorted({a.get("type", "unknown") for a in annotations}) if annotations else []
            )
            or None,
            # CH not the primary data source (FCA etc.) - completeness caveat
            "partial_data_available": d.get("partial_data_available"),
            # when a converted/closed/dissolved/removed company ceased
            "date_of_cessation": d.get("date_of_cessation"),
            # accounting reference date + next period end: captured now so the
            # phase-1.2 deadline reconstruction has them in historical cache
            "ard_day": ard.get("day"),
            "ard_month": ard.get("month"),
            "next_accounts_period_end": next_accounts.get("period_end_on"),
        }
    )
    return base


def _first_not_none(*values):
    for v in values:
        if v is not None:
            return v
    return None


# Insolvency case types that describe a SOLVENT winding-up. Members' voluntary
# liquidation is routinely used for retirement/reorganisation and is not an
# adverse event; a blanket "insolvency = high severity" would misclassify it.
SOLVENT_CASE_TYPES = {"members-voluntary-liquidation"}


def derive_insolvency(cached: CachedResponse | None) -> dict[str, Any]:
    """Summarise the insolvency resource (case-level evidence for the rules)."""
    if cached is None or cached.not_found or cached.data is None:
        return {
            "insolvency_n_cases": None,
            "insolvency_case_types": None,
            "insolvency_adverse_case_types": None,
            "insolvency_solvent_case_types": None,
        }
    cases = cached.data.get("cases") or []
    types = sorted({c.get("type", "unknown") for c in cases})
    adverse = [t for t in types if t not in SOLVENT_CASE_TYPES]
    solvent = [t for t in types if t in SOLVENT_CASE_TYPES]
    return {
        "insolvency_n_cases": len(cases),
        "insolvency_case_types": ",".join(types) if types else None,
        "insolvency_adverse_case_types": ",".join(adverse) if adverse else None,
        "insolvency_solvent_case_types": ",".join(solvent) if solvent else None,
    }


_OFFICER_KEYS = (
    "n_officers_total",
    "n_officers_active",
    "n_officers_resigned",
    "n_appointments_last_24m",
    "n_resignations_last_24m",
    "officer_churn_24m",
    "n_officers_id_verified",
    "n_officers_id_verification_due",
    "n_officers_id_statement_filed",
)


def derive_officers(cached: CachedResponse | None) -> dict[str, Any]:
    """Officer counts and 24-month churn from the merged officers resource.

    The 24-month windows are measured against the response's fetched_at (as
    age_months is), never "now", so a re-derive months later reproduces the
    original values. appointed_on / resigned_on are tolerated absent (older
    records, and appointment records mid-ECCTA identity-verification rollout).
    """
    if cached is None or cached.not_found or cached.data is None:
        return dict.fromkeys(_OFFICER_KEYS, None)

    observed_date = cached.fetched_at.date()
    items = cached.data.get("items") or []
    n_active = n_resigned = n_appt_24m = n_resign_24m = 0
    for o in items:
        resigned_on = _parse_date(o.get("resigned_on"))
        if resigned_on is None:
            n_active += 1
        else:
            n_resigned += 1
            if 0 <= _months_between(resigned_on, observed_date) < 24:
                n_resign_24m += 1
        appointed_on = _parse_date(o.get("appointed_on"))
        if appointed_on is not None and 0 <= _months_between(appointed_on, observed_date) < 24:
            n_appt_24m += 1
    n_id_verified, n_id_due, n_id_stmt = _id_verification_counts(items)
    return {
        "n_officers_total": len(items),
        "n_officers_active": n_active,
        "n_officers_resigned": n_resigned,
        "n_appointments_last_24m": n_appt_24m,
        "n_resignations_last_24m": n_resign_24m,
        "officer_churn_24m": n_appt_24m + n_resign_24m,
        "n_officers_id_verified": n_id_verified,
        "n_officers_id_verification_due": n_id_due,
        "n_officers_id_statement_filed": n_id_stmt,
    }


def derive_psc(
    psc: CachedResponse | None, statements: CachedResponse | None
) -> dict[str, Any]:
    """PSC list + statements as SEPARATE fields - deliberately not one enum.

    psc_fetch_status is PIPELINE state (did we fetch the PSC list), never a
    company signal: a company's beneficial-ownership posture lives in
    psc_information_state and active_psc_statement_codes, not here. A cached 404
    is "not_found" (a completed fetch of a legitimately-absent resource), which
    is distinct from "not_fetched" (the pipeline never asked).

    Statement codes are preserved VERBATIM - official spelling and all. Several
    of the registry's statement constants are misspelled upstream
    (companieshouse/api-enumerations psc_descriptions.yml); normalising them
    here would silently break the rule that matches on those literals.
    """
    # Pipeline/fetch state, read from the PSC list endpoint only.
    if psc is None:
        fetch_status = "not_fetched"
    elif psc.not_found:
        fetch_status = "not_found"
    else:
        fetch_status = "ok"

    # PSC list records. `zero` distinguishes "never fetched" (None -> unknown,
    # not "zero PSCs") from a cached 404 (0 -> legitimately none filed). The
    # structured ownership features below follow the same rule: None when not
    # fetched, and the "absent" value (0 / None / False) on a cached 404.
    zero = 0 if (psc is not None and psc.not_found) else None
    absent_bool = None if zero is None else False
    if psc is None or psc.not_found or psc.data is None:
        n_records = n_ceased = n_active_records = zero
        psc_id_verified = psc_id_due = psc_id_stmt = zero
        psc_natures = None
        max_ownership_band = max_voting_band = None
        has_appointment_rights = has_significant_influence = absent_bool
        n_distinct_natures = zero
        n_individual = n_corporate = n_legal_person = n_super_secure = zero
        corporate_reg_numbers = unmapped_natures = None
        n_corporate_uk_format = zero
    else:
        records = psc.data.get("items") or []
        n_active_records, n_ceased = _psc_active_ceased(psc.data, records, psc.company_number)
        # true total: the list resource may omit ceased items, so len(records)
        # alone would understate it - active + ceased is the register total.
        n_records = n_active_records + n_ceased
        psc_id_verified, psc_id_due, psc_id_stmt = _id_verification_counts(records)
        active_records = [r for r in records if not _psc_item_ceased(r)]
        natures = sorted(
            {n for r in active_records for n in (r.get("natures_of_control") or [])}
        )
        psc_natures = ",".join(natures) if natures else None
        # Structured ownership-control features over ACTIVE records only (same scope
        # as psc_natures_of_control). Decomposition lives in psc_natures.py so the
        # bulk-snapshot loader and this path share one nature-of-control mapping.
        summary = summarise_natures(natures)
        max_ownership_band = summary.max_ownership_band
        max_voting_band = summary.max_voting_band
        has_appointment_rights = summary.has_appointment_rights
        has_significant_influence = summary.has_significant_influence
        n_distinct_natures = summary.n_distinct_natures
        unmapped_natures = ",".join(summary.unmapped) if summary.unmapped else None
        categories = [classify_kind(r.get("kind")) for r in active_records]
        n_individual = categories.count("individual")
        n_corporate = categories.count("corporate")
        n_legal_person = categories.count("legal-person")
        n_super_secure = categories.count("super-secure")
        # Corporate-entity PSCs: capture the registration number verbatim (a company
        # identifier, not personal data) for the future ownership-chain join, and
        # count how many are UK-company-number format. No chain is built here.
        reg_numbers: list[str] = []
        n_corporate_uk_format = 0
        for r in active_records:
            if classify_kind(r.get("kind")) != "corporate":
                continue
            identification = r.get("identification") or {}
            regno = identification.get("registration_number")
            if regno:
                reg_numbers.append(str(regno))
                if is_uk_company_number_format(regno):
                    n_corporate_uk_format += 1
        corporate_reg_numbers = ",".join(reg_numbers) if reg_numbers else None

    # Active statement codes: verbatim `statement` values with no ceased_on.
    active_codes: list[str] = []
    if statements is not None and not statements.not_found and statements.data is not None:
        for s in statements.data.get("items") or []:
            if s.get("ceased_on"):
                continue
            code = s.get("statement")
            if code is not None:
                active_codes.append(code)

    # Derived state. "unknown" only when a resource was never fetched; a cached
    # 404 is a completed fetch of a legitimately-absent resource, not
    # incompleteness.
    if psc is None or statements is None:
        info_state = "unknown"
    elif n_active_records:
        info_state = "identified"
    elif active_codes:
        info_state = "statement_only"
    else:
        info_state = "none_reported"

    return {
        "psc_fetch_status": fetch_status,
        "psc_n_records": n_records,
        "psc_n_ceased": n_ceased,
        "active_psc_statement_codes": ",".join(active_codes) if active_codes else None,
        "psc_information_state": info_state,
        "psc_natures_of_control": psc_natures,
        "psc_max_ownership_band": max_ownership_band,
        "psc_max_voting_band": max_voting_band,
        "psc_has_appointment_rights": has_appointment_rights,
        "psc_has_significant_influence": has_significant_influence,
        "psc_n_distinct_natures": n_distinct_natures,
        "psc_n_individual": n_individual,
        "psc_n_corporate": n_corporate,
        "psc_n_legal_person": n_legal_person,
        "psc_n_super_secure": n_super_secure,
        "psc_corporate_reg_numbers": corporate_reg_numbers,
        "psc_n_corporate_uk_format_regno": n_corporate_uk_format,
        "psc_unmapped_natures": unmapped_natures,
        "n_psc_id_verified": psc_id_verified,
        "n_psc_id_verification_due": psc_id_due,
        "n_psc_id_statement_filed": psc_id_stmt,
    }


def derive_all(
    profiles: list[CachedResponse],
    insolvency_by_number: dict[str, CachedResponse] | None = None,
    officers_by_number: dict[str, CachedResponse] | None = None,
    psc_by_number: dict[str, CachedResponse] | None = None,
    psc_statements_by_number: dict[str, CachedResponse] | None = None,
) -> list[dict[str, Any]]:
    insolvency_by_number = insolvency_by_number or {}
    officers_by_number = officers_by_number or {}
    psc_by_number = psc_by_number or {}
    psc_statements_by_number = psc_statements_by_number or {}
    out = []
    for p in profiles:
        rec = derive_profile(p)
        rec.update(derive_insolvency(insolvency_by_number.get(p.company_number)))
        rec.update(derive_officers(officers_by_number.get(p.company_number)))
        rec.update(
            derive_psc(
                psc_by_number.get(p.company_number),
                psc_statements_by_number.get(p.company_number),
            )
        )
        out.append(rec)
    return out


# ---------------------------------------------------------------------------
# Field-level data dictionary. Verification tier is a property of the FIELD,
# not the company row (attributes with different evidence levels cannot share
# one per-row tier column), so it lives here and renders to docs/.
# Tiers: 1 = registrar-recorded status/event/compliance field;
#        2 = filed-but-constrained (content chosen by the company within rules);
#        3 = self-declared, weakly constrained.
# ---------------------------------------------------------------------------

FIELD_DOCS: list[dict[str, str | int]] = [
    {
        "field": "company_number",
        "tier": 1,
        "source": "profile:company_number",
        "definition": "Registrar-assigned identifier.",
        "caveats": "",
    },
    {
        "field": "observed_at",
        "tier": 1,
        "source": "cache envelope fetched_at",
        "definition": "Timestamp of the cached API response all values derive from.",
        "caveats": "Distinct from event dates and from any bulk snapshot_date.",
    },
    {
        "field": "company_name",
        "tier": 3,
        "source": "profile:company_name",
        "definition": "Registered name.",
        "caveats": "No constraint on describing activity.",
    },
    {
        "field": "company_status",
        "tier": 1,
        "source": "profile:company_status",
        "definition": "Registrar-recorded status from formal events.",
        "caveats": "",
    },
    {
        "field": "company_status_detail",
        "tier": 1,
        "source": "profile:company_status_detail",
        "definition": "Status detail, e.g. active-proposal-to-strike-off.",
        "caveats": "",
    },
    {
        "field": "company_type",
        "tier": 1,
        "source": "profile:type",
        "definition": "Legal form, assigned at registration.",
        "caveats": "",
    },
    {
        "field": "jurisdiction",
        "tier": 1,
        "source": "profile:jurisdiction",
        "definition": "Registering jurisdiction.",
        "caveats": "",
    },
    {
        "field": "date_of_creation",
        "tier": 1,
        "source": "profile:date_of_creation",
        "definition": "Incorporation date.",
        "caveats": "Shelf companies mean age is not trading history.",
    },
    {
        "field": "age_months",
        "tier": 1,
        "source": "derived",
        "definition": "Whole months from date_of_creation to observed_at.",
        "caveats": "Derived transformation, not a registrar event.",
    },
    {
        "field": "sic_codes",
        "tier": 3,
        "source": "profile:sic_codes",
        "definition": "Self-declared nature-of-business codes.",
        "caveats": "Never verified; often stale; catch-all codes common; measurement error is "
        "non-random (newer/smaller/agent-formed companies noisier).",
    },
    {
        "field": "n_previous_names",
        "tier": 1,
        "source": "profile:previous_company_names",
        "definition": "Count of recorded previous names.",
        "caveats": "",
    },
    {
        "field": "accounts_overdue",
        "tier": 1,
        "source": "profile:accounts.next_accounts.overdue (fallback deprecated accounts.overdue)",
        "definition": "CH-computed overdue flag vs statutory deadline.",
        "caveats": "Correlates with company size/resources, not only distress.",
    },
    {
        "field": "last_accounts_type",
        "tier": 2,
        "source": "profile:accounts.last_accounts.type",
        "definition": "Category of last filed accounts (micro-entity/small/full/dormant/...).",
        "caveats": "Reflects the company's disclosure choice within size thresholds; a size "
        "signal, not a risk signal.",
    },
    {
        "field": "has_charges_link",
        "tier": 1,
        "source": "profile:links.charges",
        "definition": "Charges resource exists for the company.",
        "caveats": "Presence of registered charges is normal for financed businesses.",
    },
    {
        "field": "has_insolvency_link",
        "tier": 1,
        "source": "profile:links.insolvency",
        "definition": "Insolvency resource exists for the company.",
        "caveats": "Case types must be classified before severity: MVL is solvent.",
    },
    {
        "field": "has_charges",
        "tier": 1,
        "source": "profile:has_charges (deprecated)",
        "definition": "Deprecated boolean; retained as fallback for older cached responses.",
        "caveats": "Spec: 'Please use links.charges'.",
    },
    {
        "field": "has_insolvency_history",
        "tier": 1,
        "source": "profile:has_insolvency_history (deprecated)",
        "definition": "Deprecated boolean; fallback only.",
        "caveats": "Spec: 'Please use links.insolvency'.",
    },
    {
        "field": "has_been_liquidated",
        "tier": 1,
        "source": "profile:has_been_liquidated (deprecated)",
        "definition": "Deprecated boolean; fallback insolvency indicator only.",
        "caveats": "Inconsistently present in live responses; absence is None (unknown), never "
        "False - do not coerce.",
    },
    {
        "field": "has_super_secure_pscs",
        "tier": 1,
        "source": "profile:has_super_secure_pscs",
        "definition": "Company has one or more legally protected ('super secure') PSCs whose "
        "details are withheld from the public register.",
        "caveats": "A legitimate reason for no visible PSC record; read alongside "
        "psc_information_state so protected ownership is not misread as none_reported.",
    },
    {
        "field": "insolvency_case_types",
        "tier": 1,
        "source": "insolvency:cases[].type",
        "definition": "Distinct case types on the fetched insolvency resource.",
        "caveats": "members-voluntary-liquidation is a solvent winding-up.",
    },
    {
        "field": "registered_office_is_in_dispute",
        "tier": 1,
        "source": "profile:registered_office_is_in_dispute",
        "definition": "Registrar-set dispute flag (ECCTA powers).",
        "caveats": "",
    },
    {
        "field": "undeliverable_registered_office_address",
        "tier": 1,
        "source": "profile:undeliverable_registered_office_address",
        "definition": "Registrar-set undeliverable-address flag.",
        "caveats": "",
    },
    {
        "field": "office_postcode",
        "tier": 2,
        "source": "profile:registered_office_address",
        "definition": "Registered office postcode.",
        "caveats": "Shared/agent addresses are common and legitimate; address-derived features "
        "proxy socioeconomic geography.",
    },
    {
        "field": "excluded_status",
        "tier": 1,
        "source": "derived from company_status",
        "definition": "True when status is dissolved/converted-closed/closed/removed: not "
        "screenable, reported separately.",
        "caveats": "",
    },
    {
        "field": "n_corporate_annotations",
        "tier": 1,
        "source": "profile:corporate_annotation[]",
        "definition": "Count of registrar-published corporate annotations (messages by "
        "Companies House about the company or its information).",
        "caveats": "Rare; types in corporate_annotation_types. Semantically adjacent to the "
        "address-dispute flags - review when present.",
    },
    {
        "field": "partial_data_available",
        "tier": 1,
        "source": "profile:partial_data_available",
        "definition": "Set when Companies House is not the primary data source for this "
        "company (e.g. FCA, Department for the Economy).",
        "caveats": "Completeness caveat: other indicators are weaker where this is set.",
    },
    {
        "field": "date_of_cessation",
        "tier": 1,
        "source": "profile:date_of_cessation",
        "definition": "Date the company was converted/closed, dissolved or removed (see "
        "company_status for which).",
        "caveats": "",
    },
    {
        "field": "ard_day / ard_month",
        "tier": 1,
        "source": "profile:accounts.accounting_reference_date",
        "definition": "Accounting reference date (day, month).",
        "caveats": "Captured now as the anchor for phase-1.2 deadline reconstruction.",
    },
    {
        "field": "next_accounts_period_end",
        "tier": 1,
        "source": "profile:accounts.next_accounts.period_end_on",
        "definition": "Last day of the next accounting period to be filed.",
        "caveats": "Captured for phase-1.2 deadline reconstruction.",
    },
    {
        "field": "n_officers_total",
        "tier": 2,
        "source": "officers:items[] (paginated, merged)",
        "definition": "Total officer appointments on record (active + resigned).",
        "caveats": "Officer identities historically unverified; ECCTA identity verification is "
        "mid-rollout (2025-2026), so this is filed-but-constrained, not verified. Count of "
        "appointments, not distinct persons.",
    },
    {
        "field": "n_officers_active",
        "tier": 2,
        "source": "officers:items[] with no resigned_on",
        "definition": "Appointments with no resignation date recorded.",
        "caveats": "Missing resigned_on is read as active; older records omit dates.",
    },
    {
        "field": "n_officers_resigned",
        "tier": 2,
        "source": "officers:items[] with resigned_on",
        "definition": "Appointments carrying a resignation date.",
        "caveats": "Depends on resigned_on being filed; tolerated absent.",
    },
    {
        "field": "n_appointments_last_24m",
        "tier": 2,
        "source": "derived from officers:items[].appointed_on",
        "definition": "Appointments dated within 24 months before observed_at.",
        "caveats": "Windowed against the response fetched_at, not now. appointed_on tolerated "
        "absent (not counted).",
    },
    {
        "field": "n_resignations_last_24m",
        "tier": 2,
        "source": "derived from officers:items[].resigned_on",
        "definition": "Resignations dated within 24 months before observed_at.",
        "caveats": "Windowed against the response fetched_at, not now.",
    },
    {
        "field": "officer_churn_24m",
        "tier": 2,
        "source": "derived",
        "definition": "n_appointments_last_24m + n_resignations_last_24m.",
        "caveats": "A movement count, not a risk signal; high churn is normal for some legitimate "
        "structures. Attribute only - no rule keys off it in this phase.",
    },
    {
        "field": "n_officers_id_verified",
        "tier": 2,
        "source": "officers:items[].identity_verification_details (present)",
        "definition": "Officer appointments carrying an ECCTA identity-verification block.",
        "caveats": "Rollout in progress (2025-2026); absence means unverified-or-not-yet-due, not "
        "non-compliance. Counts the block's presence, not a completed identity_verified_on.",
    },
    {
        "field": "n_officers_id_verification_due",
        "tier": 2,
        "source": "derived from officers:items[].identity_verification_details",
        "definition": "Appointments with a verification statement due "
        "(appointment_verification_statement_due_on) and no completed identity_verified_on.",
        "caveats": "Rollout in progress; absence of the block means unverified-or-not-yet-due, not "
        "non-compliance. Key names as observed live 2026-08 (see AUDIT).",
    },
    {
        "field": "n_officers_id_statement_filed",
        "tier": 2,
        "source": "officers:items[].identity_verification_details."
        "appointment_verification_statement_date",
        "definition": "Appointments with a filed appointment-verification statement.",
        "caveats": "A SEPARATE signal from identity verification: a filed statement does not set "
        "identity_verified_on and does not clear n_officers_id_verification_due. Rollout in "
        "progress.",
    },
    {
        "field": "psc_fetch_status",
        "tier": 1,
        "source": "pipeline state (PSC list endpoint fetch outcome)",
        "definition": "ok / not_found / not_fetched for the persons-with-significant-control "
        "list resource.",
        "caveats": "PIPELINE STATE, never a company signal: it records whether we fetched the "
        "resource, not anything about the company. Never appears as flag evidence. The company's "
        "PSC posture is psc_information_state + active_psc_statement_codes. In the 2026-08 live "
        "batch the psc-statements endpoint returned 404 for every company with no statement "
        "filed, consistent with 404 = none filed.",
    },
    {
        "field": "psc_n_records",
        "tier": 1,
        "source": "psc:items[]",
        "definition": "Count of PSC records on the list resource (active + ceased).",
        "caveats": "None (not 0) when the list was not fetched, so a missing fetch is not read as "
        "'no PSCs'. 0 on a cached 404 (legitimately none filed).",
    },
    {
        "field": "psc_n_ceased",
        "tier": 1,
        "source": "psc:items[] with ceased_on",
        "definition": "PSC records carrying a ceased_on date.",
        "caveats": "Ceased PSCs are historical; active beneficial ownership is n_records - "
        "n_ceased.",
    },
    {
        "field": "active_psc_statement_codes",
        "tier": 1,
        "source": "psc_statements:items[].statement where ceased_on absent",
        "definition": "Comma-joined verbatim statement constants for statements with no "
        "ceased_on (e.g. steps-to-find-psc-not-yet-completed).",
        "caveats": "VERBATIM official values from psc_descriptions.yml, incl. upstream "
        "misspellings - never normalised, because rules match these literals. Ceased statements "
        "excluded.",
    },
    {
        "field": "psc_information_state",
        "tier": 1,
        "source": "derived from psc + psc_statements",
        "definition": "identified (>=1 active PSC record) / statement_only (no records, >=1 "
        "active statement) / none_reported (neither) / unknown (a resource not fetched).",
        "caveats": "Derived transformation over both PSC resources. 'unknown' is fetch "
        "incompleteness, distinct from 'none_reported'.",
    },
    {
        "field": "psc_natures_of_control",
        "tier": 2,
        "source": "psc:items[].natures_of_control (active records)",
        "definition": "Sorted, distinct, comma-joined natures-of-control across ACTIVE PSC "
        "records (e.g. ownership-of-shares-25-to-50-percent).",
        "caveats": "Verbatim enum values, never normalised. Ceased PSC records excluded.",
    },
    {
        "field": "psc_max_ownership_band",
        "tier": 2,
        "source": "derived from psc:items[].natures_of_control (active records)",
        "definition": "Highest share-ownership band held by any active PSC: one of "
        "25-to-50-percent / 50-to-75-percent / 75-to-100-percent.",
        "caveats": "Decomposition shared with the bulk loader via psc_natures.py (validated "
        "against all 86 published nature codes). Registered-overseas-entity 'more-than-25-percent' "
        "thresholds are captured as a band value but excluded from this max-band ranking (not "
        "ordinally comparable to the '-to-' bands), so an ROE-only holding yields None, as does "
        "no ownership nature at all.",
    },
    {
        "field": "psc_max_voting_band",
        "tier": 2,
        "source": "derived from psc:items[].natures_of_control (active records)",
        "definition": "Highest voting-rights band held by any active PSC (same band values as "
        "psc_max_ownership_band).",
        "caveats": "As psc_max_ownership_band: ROE 'more-than' thresholds are captured but not "
        "ranked, so an ROE-only holding yields None.",
    },
    {
        "field": "psc_has_appointment_rights",
        "tier": 2,
        "source": "derived from psc:items[].natures_of_control (active records)",
        "definition": "True when any active PSC holds a right-to-appoint-and-remove nature.",
        "caveats": "Covers the whole right-to-appoint-and-remove family (directors, LLP members, "
        "firm/trust persons), not directors alone. None (unknown) only when the PSC list was not "
        "fetched; False on a cached 404.",
    },
    {
        "field": "psc_has_significant_influence",
        "tier": 2,
        "source": "derived from psc:items[].natures_of_control (active records)",
        "definition": "True when any active PSC holds significant-influence-or-control.",
        "caveats": "None (unknown) only when the PSC list was not fetched; False on a cached 404.",
    },
    {
        "field": "psc_n_distinct_natures",
        "tier": 2,
        "source": "derived from psc:items[].natures_of_control (active records)",
        "definition": "Count of distinct verbatim nature-of-control codes across active PSCs.",
        "caveats": "Counts all distinct codes including any unmapped ones (see "
        "psc_unmapped_natures). None when the list was not fetched; 0 on a cached 404.",
    },
    {
        "field": "psc_n_individual",
        "tier": 1,
        "source": "psc:items[].kind (active records)",
        "definition": "Active PSC records classified as individuals.",
        "caveats": "Classification shared with the bulk loader via psc_natures.py. Counts active "
        "records only; ROE individual beneficial-owner variants fold into this category.",
    },
    {
        "field": "psc_n_corporate",
        "tier": 1,
        "source": "psc:items[].kind (active records)",
        "definition": "Active PSC records classified as corporate entities.",
        "caveats": "Includes ROE corporate beneficial-owner variants. The on-ramp to ownership "
        "networks: see psc_corporate_reg_numbers.",
    },
    {
        "field": "psc_n_legal_person",
        "tier": 1,
        "source": "psc:items[].kind (active records)",
        "definition": "Active PSC records classified as legal persons.",
        "caveats": "Counts active records only.",
    },
    {
        "field": "psc_n_super_secure",
        "tier": 1,
        "source": "psc:items[].kind (active records)",
        "definition": "Active PSC records classified as super-secure.",
        "caveats": "Super-secure details are withheld from the register; read alongside the "
        "profile flag has_super_secure_pscs, which can be set even when no list item appears.",
    },
    {
        "field": "psc_corporate_reg_numbers",
        "tier": 2,
        "source": "psc:items[].identification.registration_number (active corporate records)",
        "definition": "Comma-joined verbatim registration numbers of active corporate-entity PSCs.",
        "caveats": "Company identifiers, not personal data. Captured verbatim for a future "
        "ownership-chain join; no chain is built. None when there are no corporate PSCs with a "
        "registration number.",
    },
    {
        "field": "psc_n_corporate_uk_format_regno",
        "tier": 2,
        "source": "derived from psc:items[].identification.registration_number",
        "definition": "Count of active corporate-PSC registration numbers that normalise to a "
        "valid Companies House company number (8 digits or 2-letter prefix + 6 digits).",
        "caveats": "A format gate via validate.normalise_company_number (the same rule as input "
        "validation), not proof the company exists; it zero-pads short all-digit values, so a "
        "short foreign id can read as UK-format. None when the list was not fetched; 0 on a 404.",
    },
    {
        "field": "psc_unmapped_natures",
        "tier": 2,
        "source": "derived from psc:items[].natures_of_control (active records)",
        "definition": "Comma-joined nature codes whose core right the shared mapping did not "
        "recognise (normally empty).",
        "caveats": "All 86 codes in the published enumeration (psc_descriptions.yml @ 0d3fb78) "
        "decompose cleanly, so this is expected to be None; a non-empty value flags a code added "
        "to the register since that enumeration, for review rather than silent dropping.",
    },
    {
        "field": "n_psc_id_verified",
        "tier": 2,
        "source": "psc:items[].identity_verification_details (present)",
        "definition": "PSC records carrying an ECCTA identity-verification block.",
        "caveats": "Rollout in progress (2025-2026); absence means unverified-or-not-yet-due, not "
        "non-compliance. Counts the block's presence, not a completed identity_verified_on. This "
        "block-presence count is cumulative - unlike n_psc_id_verification_due and "
        "n_psc_id_statement_filed, which are point-in-time - and showed zero decreases in "
        "bulk-vs-API parity (docs/psc-parity-2026-09-25.md).",
    },
    {
        "field": "n_psc_id_verification_due",
        "tier": 2,
        "source": "derived from psc:items[].identity_verification_details",
        "definition": "PSC records with a verification statement due "
        "(appointment_verification_statement_due_on) and no completed identity_verified_on.",
        "caveats": "Rollout in progress; absence of the block means unverified-or-not-yet-due, not "
        "non-compliance. POINT-IN-TIME, not cumulative: it reflects the current verification "
        "cycle and falls when a due is cleared by completed verification, so a later snapshot can "
        "show fewer. The annual-cycle reset mechanism is INFERRED (from bulk-vs-API behaviour, "
        "docs/psc-parity-2026-09-25.md), NOT VERIFIED against CH documentation. Key names as "
        "observed live 2026-08 (see AUDIT).",
    },
    {
        "field": "n_psc_id_statement_filed",
        "tier": 2,
        "source": "psc:items[].identity_verification_details."
        "appointment_verification_statement_date",
        "definition": "PSC records with a filed appointment-verification statement.",
        "caveats": "A SEPARATE signal from identity verification: a filed statement does not set "
        "identity_verified_on and does not clear n_psc_id_verification_due. POINT-IN-TIME, not "
        "cumulative: it reflects the current verification cycle, so a later snapshot can show "
        "fewer - it decreased for 53 companies between the 2026-08 API cache and the 2026-09-25 "
        "bulk snapshot with no PSC membership change (docs/psc-parity-2026-09-25.md). The inferred "
        "cause (appointment_verification_statement_date clears when the cycle resets) is NOT "
        "VERIFIED against CH documentation. Observed live on 07083592 (statement filed, "
        "identity_verified_on absent). Rollout in progress.",
    },
    # ------------------------------------------------------------------------
    # Snapshot-derived features (Handoff 08): one row per live company from the
    # basic-company bulk file, built by ukcompany.snapshot.features. Shared-name
    # attributes already documented above (company_status, company_type,
    # date_of_creation, age_months, n_previous_names, accounts_overdue) carry the
    # same definitions; the snapshot source differs (dates are DD/MM/YYYY and the
    # reference for age/overdue is the snapshot date, not today) - see
    # docs/snapshot-features.md. Only the snapshot-new attributes are listed here.
    # ------------------------------------------------------------------------
    {
        "field": "sic_sections",
        "tier": 3,
        "source": "snapshot:SICCode.SicText_1..4 -> sic_section_from_code",
        "definition": "Distinct SIC-2007 section letters across the company's up-to-four SIC "
        "codes, via the shared sic_section_from_code.",
        "caveats": "SIC is self-declared by the company (Tier 3). Codes are read from the "
        "'CODE - description' text. 'unknown' when a code is blank/unmappable.",
    },
    {
        "field": "n_sic_codes",
        "tier": 3,
        "source": "snapshot:SICCode.SicText_1..4",
        "definition": "Number of SIC codes recorded (0-4).",
        "caveats": "Self-declared. The bulk file caps SIC codes at four.",
    },
    {
        "field": "flag_dormant_sic",
        "tier": 3,
        "source": "snapshot:SICCode.SicText_* == 99999",
        "definition": "Any SIC code is 99999 (Dormant Company).",
        "caveats": "A self-declared SIC marker, SEPARATE from the DORMANT accounts category; the "
        "two need not agree.",
    },
    {
        "field": "flag_non_trading_sic",
        "tier": 3,
        "source": "snapshot:SICCode.SicText_* == 74990",
        "definition": "Any SIC code is 74990 (Non-trading company).",
        "caveats": "Self-declared; distinct from the dormant marker and the accounts category.",
    },
    {
        "field": "flag_nec_sic",
        "tier": 3,
        "source": "snapshot:SICCode.SicText_* in NEC_SIC_CODES",
        "definition": "Any SIC code is a 'not elsewhere classified' (n.e.c.) code.",
        "caveats": "n.e.c. list enumerated from SIC-2007 condensed-list descriptions ending "
        "'n.e.c.' (ONS UK SIC 2007); a malformed 4-digit variant in the data is excluded. "
        "Self-declared.",
    },
    {
        "field": "n_charges",
        "tier": 1,
        "source": "snapshot:Mortgages.NumMortCharges",
        "definition": "Total charges (mortgages) recorded against the company.",
        "caveats": "Registrar charge-register count.",
    },
    {
        "field": "n_charges_outstanding",
        "tier": 1,
        "source": "snapshot:Mortgages.NumMortOutstanding",
        "definition": "Charges currently outstanding.",
        "caveats": "Registrar charge-register count.",
    },
    {
        "field": "n_charges_part_satisfied",
        "tier": 1,
        "source": "snapshot:Mortgages.NumMortPartSatisfied",
        "definition": "Charges recorded as part-satisfied.",
        "caveats": "Registrar charge-register count.",
    },
    {
        "field": "n_charges_satisfied",
        "tier": 1,
        "source": "snapshot:Mortgages.NumMortSatisfied",
        "definition": "Charges recorded as satisfied.",
        "caveats": "Registrar charge-register count.",
    },
    {
        "field": "accounts_category",
        "tier": 1,
        "source": "snapshot:Accounts.AccountCategory",
        "definition": "The accounts category of the last accounts filed (e.g. MICRO ENTITY, "
        "DORMANT, NO ACCOUNTS FILED), upper-cased.",
        "caveats": "Registrar-assigned from the filing; 'NO ACCOUNTS FILED' includes companies "
        "not yet past their first deadline (see accounts_never_filed). In the accounts-feature "
        "table this is paired to a reference T by the end-of-month rule: the register snapshot "
        "(dated YYYY-MM-01, reflecting the start of that month) taken is the latest one dated <= the "
        "first day of T+1, i.e. the (month-after-T)-01 snapshot - NOT a same-numbered-month one.",
    },
    {
        "field": "confirmation_statement_overdue",
        "tier": 1,
        "source": "snapshot:ConfStmtNextDueDate < snapshot_date",
        "definition": "The confirmation statement's next-due date is before the snapshot date.",
        "caveats": "Computed against the snapshot date (the reference), never today. Null due "
        "date (e.g. brand-new company) is treated as not overdue.",
    },
    {
        "field": "accounts_never_filed",
        "tier": 1,
        "source": "snapshot:Accounts.AccountCategory + Accounts.NextDueDate",
        "definition": "Accounts category is 'NO ACCOUNTS FILED' AND CH's computed next-due date "
        "(Accounts.NextDueDate) is before the snapshot date.",
        "caveats": "Uses CH's own computed accounts deadline, which already handles the PLC "
        "18-month case, the 3-months-from-ARD alternative, ARD changes and extensions - no "
        "hand-coded deadline. A null next-due date (a very new company whose deadline is not yet "
        "computed) is treated as not-yet-overdue.",
    },
    {
        "field": "n_companies_same_postcode",
        "tier": 1,
        "source": "snapshot:RegAddress.PostCode (derived concentration)",
        "definition": "Number of live companies sharing the company's registered-office postcode "
        "in this snapshot.",
        "caveats": "The upper tail is formation agents / virtual offices. A concentration count, "
        "not a relationship. Governed tier.",
    },
    {
        "field": "n_companies_same_address",
        "tier": 1,
        "source": "snapshot:RegAddress.PostCode + AddressLine1 (derived concentration)",
        "definition": "Number of live companies sharing the company's normalised registered "
        "address (postcode + first line) in this snapshot.",
        "caveats": "UNGOVERNED tier only - registered offices are sometimes home addresses, so a "
        "per-address count says something about a household. Normalisation per "
        "ukcompany.snapshot.features.normalise_address; counts are insensitive to it (<0.1% of "
        "distinct addresses shift under strict vs loose).",
    },
    # --- Accounts (iXBRL WIDE) features, point-in-time at reference month T (Handoff 02) -------
    # Built from the WIDE `as_first_reported` table + its `row_available_yyyymm` key. Tier 2:
    # figures are filed by the company within accounting standards, and iXBRL tagging quality
    # varies. COVERAGE IS STRONGLY SIZE-SKEWED - see latest_period_end / equity caveats.
    {
        "field": "latest_period_end",
        "tier": 2,
        "source": "accounts WIDE:period_end (as_first_reported, available by T)",
        "definition": "Balance-sheet date of the most recent accounts available by end-of-month T "
        "(point-in-time: only rows whose archive month is <= T; T is an end-of-month boundary).",
        "caveats": "COVERAGE IS STRONGLY SIZE-SKEWED: iXBRL accounts data is far more complete for "
        "larger entities; the smallest micro-entities and dormant companies are heavily "
        "under-represented, so the absence of a row is NOT the absence of the company. Row-level "
        "point-in-time (only ~0.0036% of WIDE rows span more than one archive month).",
    },
    {
        "field": "prior_period_end",
        "tier": 2,
        "source": "accounts WIDE:period_end (second-newest available by T)",
        "definition": "Balance-sheet date of the second-most-recent accounts available by T.",
        "caveats": "Null when only one period is available by T.",
    },
    {
        "field": "n_periods_available",
        "tier": 2,
        "source": "accounts WIDE (derived count available by T)",
        "definition": "Count of distinct accounts periods for the company available by T.",
        "caveats": "Point-in-time count; filings whose archive month is after T are excluded.",
    },
    {
        "field": "months_since_latest_period_end",
        "tier": 2,
        "source": "derived",
        "definition": "(T.year - latest_period_end.year)*12 + (T.month - latest_period_end.month).",
        "caveats": "Staleness proxy: months between the reference month and the latest available "
        "period end, not filing lag.",
    },
    {
        "field": "prior_gap_months",
        "tier": 2,
        "source": "derived",
        "definition": "Months between the prior and the latest available period end.",
        "caveats": "Null with no prior period. A value far from 12 indicates a shortened/extended "
        "accounting period or a gap in available filings; change features are suppressed above 18 "
        "months.",
    },
    {
        "field": "equity",
        "tier": 2,
        "source": "accounts WIDE:Equity (as_first_reported)",
        "definition": "Total equity (net assets) from the latest available accounts; scale and "
        "sign are normalised during extraction.",
        "caveats": "COVERAGE IS STRONGLY SIZE-SKEWED toward larger entities (as for all accounts "
        "figures). A tagged dash is a declared nil (0), distinct from a missing (null) tag.",
    },
    {
        "field": "current_assets",
        "tier": 2,
        "source": "accounts WIDE:CurrentAssets (as_first_reported)",
        "definition": "Current assets from the latest available accounts.",
        "caveats": "dash = declared nil (0), distinct from a missing (null) tag. Size-skewed "
        "coverage (see equity).",
    },
    {
        "field": "creditors_within_one_year",
        "tier": 2,
        "source": "accounts WIDE:creditors_within_one_year (the <1yr maturity bucket)",
        "definition": "Creditors falling due within one year, from the latest available accounts.",
        "caveats": "Uses the <1-year maturity bucket, NOT the bare Creditors total (which is only "
        "~3.8% populated). dash = declared nil (0). Size-skewed coverage (see equity).",
    },
    {
        "field": "net_current_assets",
        "tier": 2,
        "source": "accounts WIDE:NetCurrentAssetsLiabilities (as_first_reported)",
        "definition": "Net current assets (liabilities) from the latest available accounts; a "
        "negative value is net current liabilities.",
        "caveats": "Sign as filed; dash = declared nil (0). Size-skewed coverage (see equity).",
    },
    {
        "field": "cash",
        "tier": 2,
        "source": "accounts WIDE:CashBankOnHand (as_first_reported)",
        "definition": "Cash at bank and in hand from the latest available accounts.",
        "caveats": "dash = declared nil (0), distinct from a missing (null) tag. Size-skewed "
        "coverage (see equity).",
    },
    {
        "field": "negative_equity",
        "tier": 2,
        "source": "derived (equity < 0)",
        "definition": "True when the latest available total equity is negative.",
        "caveats": "Null when equity is not tagged (missing is not false). A declared nil (0) is "
        "not negative.",
    },
    {
        "field": "net_current_liabilities",
        "tier": 2,
        "source": "derived (net_current_assets < 0)",
        "definition": "True when the latest available net current assets are negative (a "
        "working-capital deficit).",
        "caveats": "Null when the figure is not tagged (missing is not false).",
    },
    {
        "field": "current_ratio",
        "tier": 2,
        "source": "derived (current_assets / creditors_within_one_year)",
        "definition": "Current assets divided by creditors due within one year, latest available "
        "accounts.",
        "caveats": "NULL (never +/-inf) when the denominator is zero or missing. Uses the <1-year "
        "maturity bucket, not the bare Creditors total.",
    },
    {
        "field": "employee_band",
        "tier": 2,
        "source": "accounts WIDE:AverageNumberEmployeesDuringPeriod (banded)",
        "definition": "Average employees during the latest available period, banded to Companies "
        "Act size thresholds: 0 / 1-10 / 11-50 / 51-250 / 251+.",
        "caveats": "BREAK AROUND 2020-21: employee-number tagging for micro/small entities changed, "
        "so band distributions are NOT comparable across that break. Null when untagged. See "
        "employees_unit_anomaly.",
    },
    {
        "field": "employees_unit_anomaly",
        "tier": 2,
        "source": "accounts WIDE:employees_unit_anomaly",
        "definition": "Diagnostic flag: the employee count was tagged with a monetary unit (e.g. "
        "GBP), suggesting a mis-tag.",
        "caveats": "DIAGNOSTIC ONLY - never alters the reported value or the band; carried through, "
        "not used to drop a value or as a cut-off.",
    },
    {
        "field": "d_equity",
        "tier": 2,
        "source": "derived (latest equity - prior equity)",
        "definition": "Change in total equity from the prior to the latest available period.",
        "caveats": "Null with no prior period or a gap > 18 months. as_first_reported figures are "
        "differenced, so this is not a restatement.",
    },
    {
        "field": "d_net_current_assets",
        "tier": 2,
        "source": "derived (latest net_current_assets - prior)",
        "definition": "Change in net current assets from the prior to the latest available period.",
        "caveats": "Null with no prior period or a gap > 18 months.",
    },
    {
        "field": "d_cash",
        "tier": 2,
        "source": "derived (latest cash - prior cash)",
        "definition": "Change in cash from the prior to the latest available period.",
        "caveats": "Null with no prior period or a gap > 18 months.",
    },
]


def generate_data_dictionary_md() -> str:
    lines = [
        "# Data dictionary: derived company attributes",
        "",
        "*Generated from `src/ukcompany/derive.py` - do not edit by hand.*",
        "",
        "Verification tier is a property of each field: 1 = registrar-recorded status/event/",
        "compliance field; 2 = filed-but-constrained; 3 = self-declared, weakly constrained.",
        "Companies House registers most information without verifying it; no field is",
        "described as verified.",
        "",
        "| field | tier | source | definition | caveats |",
        "|---|---|---|---|---|",
    ]
    for f in FIELD_DOCS:
        lines.append(
            f"| {f['field']} | {f['tier']} | {f['source']} | {f['definition']} | {f['caveats']} |"
        )
    lines.append("")
    return "\n".join(lines)
